package es.ADD.ae02;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Controlador {

	private Modelo modelo;
	private Vista vista;
	private ActionListener actionListenerBuscar, actionListenerReemplazar;
	private String ficheroLectura, ficheroEscritura;
	private String textoBuscar, textoReemplazar;
	
	public Controlador(Modelo modelo, Vista vista) {
		this.modelo= modelo;
		this.vista = vista;
		control();
	}
	
	
	public void control() {
		
		ficheroLectura = modelo.ficheroLectura();
		ficheroEscritura = modelo.ficheroEscritura();
		
		mostrarFichero(ficheroLectura,1);
		
		actionListenerBuscar = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				String textoBuscar = vista.getTextFieldBuscar().getText();
				modelo.buscarTexto(textoBuscar);
			}
			
		};
		vista.getTextFieldBuscar().addActionListener(actionListenerBuscar);
		actionListenerBuscar = (ActionListener) vista.getBtnBuscar();
		
		
		actionListenerReemplazar = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				String textoBuscar = vista.getTextFieldBuscar().getText();
				String textoReemplazar = vista.getTextFieldReemplazar().getText();
				modelo.reemplazarTexto(textoBuscar, textoReemplazar);
				mostrarFichero(ficheroLectura,2);
			}
		};
		actionListenerReemplazar= (ActionListener) vista.getBtnReemplazar();
		
		
	}
	
	
	private void mostrarFichero(String ficheroEscritura, int numeroTextArea) {
		
		ArrayList<String> arrayLineas = modelo.contenidoFichero(ficheroEscritura);
		for (String linea : arrayLineas) {
			if (numeroTextArea == 1) {
				vista.getTextAreaOriginal().append(linea+"\n");
				
			}else
				vista.getTextAreaModificado().append(linea+"\n");
			}
		}
	}


