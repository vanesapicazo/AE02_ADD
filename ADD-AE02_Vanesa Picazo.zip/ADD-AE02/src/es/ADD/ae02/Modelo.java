package es.ADD.ae02;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Modelo {
	
	private String fichero_lectura;
	private String fichero_escritura;
	
	public Modelo() {
		fichero_lectura = "AE02_T1_2_Streams_Groucho.txt";
		fichero_escritura = "ficheroEscritura.txt";
	}

	public ArrayList<String> contenidoFichero(String fichero) {
		// Este metodo devuelve una lista de strings con el contenido del fichero 
		//(cada elemento de la lista es una linea del fichero)
		ArrayList<String> contenidoFichero = new ArrayList<String>();
		File f = new File(fichero);
		try {
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			String linea = br.readLine();
			while (linea != null) {
				contenidoFichero.add(linea);
				linea = br.readLine();
			}
			br.close();
			fr.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(new JFrame(), e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
		}
		return contenidoFichero;

	}
	
	public String ficheroLectura() {
		//Este metodo devuelve un string que contiene el nombre del fichero de lectura
		return fichero_lectura;
	}
	
	public String ficheroEscritura() {
		//Este metodo devuelve un string que contiene el nombre del fichero de escritura
		return fichero_escritura;
	}
	
	
	public int buscarTexto(String textoBuscar) {
		
		File archivo = new File("AE02_T1_2_Streams_Groucho.txt");
		int contador = 0;
		int posicion = 0;
		
		try {
			FileReader fr = new FileReader(archivo);
			BufferedReader br = new BufferedReader(fr);
			Scanner sc = new Scanner(System.in);
			textoBuscar = sc.nextLine();
			
			String linea = br.readLine();
			
			posicion = linea.indexOf(textoBuscar);
			
			while (posicion != -1) {
				contador++;
				posicion = linea.indexOf(textoBuscar, posicion + 1);
			}
			fr.close();
			br.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(new JFrame(), e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
		}
		return contador;
	}
	
	public void reemplazarTexto(String textoBuscar, String textoReemplazar) {
		
		File f1 = new File("AE02_T1_2_Streams_Groucho.txt");
		String newString;
		
		try {
			FileReader fr = new FileReader(f1);
			BufferedReader br = new BufferedReader(fr);
			String oldString = textoBuscar;
			Scanner sc = new Scanner(System.in);
			textoReemplazar = sc.nextLine();
			
			newString = oldString.replaceAll(textoBuscar, textoReemplazar);
			
			
			fr.close();
			br.close();
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(new JFrame(), e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
		}
		return newString;
	}
	

}
